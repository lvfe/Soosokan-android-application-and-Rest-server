package com.cloudant.client.api;

import org.lightcouch.CouchDatabase;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CloudantClient cc = new CloudantClient("soosokan", "soosokan", "soosokan1");
		
		System.out.println(cc.getAllDbs());
		cc.deleteDB("newdb", "delete database");
	
		
		
		//cc.createDB("newdb");
		Database db = cc.database("newdb", true);
		Person p = new Person("tian", "12345dddd");
//		db.batch(p);
	    db.save(p);
	    //db.createIndex("index");
	    System.out.println( db.listIndices());
	   
		//cc.database("newdb", true);
		System.out.println(cc.getAllDbs());
		
	}

}
