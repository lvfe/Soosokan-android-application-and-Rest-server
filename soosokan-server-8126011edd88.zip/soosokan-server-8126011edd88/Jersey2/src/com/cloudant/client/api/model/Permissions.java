package com.cloudant.client.api.model;


public enum Permissions {
	_admin,
	_reader,
	_writer,
	_replicator

}

