package com.cloudant.client.api;

public class Person {

	private String userName;
	private String password;
	
	public Person(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
}
