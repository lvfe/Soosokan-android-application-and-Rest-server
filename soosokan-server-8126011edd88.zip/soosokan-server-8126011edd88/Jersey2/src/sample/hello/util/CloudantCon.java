package sample.hello.util;

import com.cloudant.client.api.CloudantClient;

public class CloudantCon {
	
	public CloudantClient con(){
		CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");
		
		return dbClient;
	}

}
