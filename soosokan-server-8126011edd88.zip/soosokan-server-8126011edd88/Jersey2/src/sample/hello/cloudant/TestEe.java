package sample.hello.cloudant;


import java.sql.Timestamp;

import sample.hello.bean.Ads;
import sample.hello.bean.Item;


public class TestEe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//warning: _id is key, when it already in db, test will be wrong, please change one before test!!!!!!!
		Boolean result1 = AdsHandler.addAds(new Ads("006", "001", "soosokan","We are soosokan", new Timestamp(123578876), 10000));
		System.out.println("save ads result: " + result1);
		
		Boolean result2 = ItemHandler.addItem(new Item("006", "001", "soosokan", "soosokan is best", 0, new Timestamp(0), 100, "C://Users/windows7/Desktop/so.png"));
		System.out.println("save item result: " + result2);
		
		Ads ads = AdsHandler.findAdsById("006");
		System.out.println("Get ads from db result: "+ads.toString());
		
		Item item = ItemHandler.findItemById("006","c://" );
		System.out.println("Get item from db result: "+item.toString());
	}

}
