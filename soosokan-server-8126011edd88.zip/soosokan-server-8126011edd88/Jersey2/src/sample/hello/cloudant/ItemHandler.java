package sample.hello.cloudant;


import java.util.ArrayList;
import java.util.List;



import sample.hello.bean.Item;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.Responses;

public class ItemHandler {
	private static CloudantClient dbClient = new CloudantClient("soosokan",
			"soosokan", "soosokan1");

	private static Database db = dbClient.database("item_db", true);

	/**
	 * Add a new item to item_db
	 * 
	 * @param item
	 *            entity which contains the information needs to update
	 * @param filePath
	 *            of the picture
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addItem(Item item) {
		boolean flag = false;
		//item.setPicId(PictureHandler.savePic(filePath, item.getItemId()));
		Responses resp = db.save(item);
		if (resp.getId().equals(item.getItemId())) {
			flag = true;
		}
		return flag;
	}

	/**
	 * Remove a item from item_db
	 * 
	 * @param id the
	 *            itemid
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deleteitem(String id) {
		boolean flag = false;
		Item item = db.find(Item.class, id);
		if (PictureHandler.deletePic(item.getPicId())) {
			Responses resp = db.remove(item);
			if (resp.getId().equals(id)) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * Update a item information to item_db
	 * 
	 * @param newItem the
	 *            new item which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updateitem(Item newItem) {
		boolean flag = false;
		Item item = db.find(Item.class, newItem.getItemId());
		item.setKeyword(newItem.getKeyword());
		item.setName(newItem.getName());
		item.setPrice(newItem.getPrice());
		item.setTime(newItem.getTime());
		Responses resp = db.update(item);
		if (resp.getId().equals(item.getItemId())) {
			flag = true;
		}
		return flag;
	}

	/**
	 * find a item from item_db, the item picture name is "itemId.png"
	 * 
	 * @param id the itemid
	 * @param filePath the filePath to save item picture
	 * @return the entity of the item
	 * @author Tian
	 */
	public static Item findItemById(String id,String filePath) {
		Item item = db.find(Item.class, id);
		PictureHandler.getPic(item.getPicId(), filePath, item.getItemId());
		return item;
	}

	//NULL???????????????
	public static List<Item> findItemBySeller() {
		List<Item> items = new ArrayList<Item>();
		return items;
	}

}
