package sample.hello.cloudant;


import java.util.ArrayList;
import java.util.List;



import sample.hello.bean.Ads;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.Responses;

public class AdsHandler {
	private static CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");

	private static Database db = dbClient.database("ads_db", true);

	/**
	 * Add a new Ads to ads_db
	 * @param  the Ads entity which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addAds(Ads Ads){
		 boolean flag = false;
	     Responses resp = db.save(Ads);
	     if(resp.getId().equals(Ads.getAdsId())){
	    	 flag = true;
	     }
	     return flag;
	}
	
	/**
	 * Remove a Ads from ads_db
	 * @param the Adsid
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deleteAds(String id){
		boolean flag = false;
		Ads Ads = db.find(Ads.class, id);
		Responses resp = db.remove(Ads);
		if(resp.getId().equals(id)){
	    	 flag = true;
	     }
		return flag;
	}
	
	/**
	 * Update a Ads information to ads_db
	 * @param the new Ads which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updateAds(Ads newAds){
		boolean flag = false;
		Ads ads = db.find(Ads.class,newAds.getAdsId());
		ads.setDescription(newAds.getDescription());
		ads.setDistance(newAds.getDistance());
		ads.setTime(newAds.getTime());
		Responses resp = db.update(ads);
		if(resp.getId().equals(ads.getAdsId())){
	    	 flag = true;
	     }
		return flag;
	}	
	
	/**
	 * find a Ads from ads_db
	 * @param the Adsid
	 * @return the entity of the Ads
	 * @author Tian
	 */
	public static Ads findAdsById(String id){
		return db.find(Ads.class, id);
	}
	
	public static List<Ads> findAdsBySeller(){
		List<Ads> Ads = new ArrayList<Ads>();
		return Ads;
	}
	

}
