package sample.hello.cloudant;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.Responses;

import org.apache.http.HttpEntity;  
import org.apache.http.HttpResponse;  
import org.apache.http.client.HttpClient;  
import org.apache.http.client.methods.*;  
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;  
import org.apache.http.client.methods.HttpGet;  
import org.apache.http.client.methods.HttpPatch;  
import org.apache.http.client.methods.HttpPost;  
import org.apache.http.client.methods.HttpPut;  
import org.apache.http.client.methods.HttpUriRequest;  
import org.apache.http.entity.ByteArrayEntity;  
import org.apache.http.entity.ContentType;  
import org.apache.http.impl.client.DefaultHttpClient;  
import org.apache.http.params.HttpConnectionParams;  
import org.apache.http.params.HttpParams;  
import org.apache.http.protocol.HTTP; 

import sample.hello.bean.Seller;
import sample.hello.util.CloudantCon;
import sample.hello.util.MD5;



public class SellerHandler{

	private static CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");
	private static  Database db = dbClient.database("seller_db", true);
	  
	/**
	 * Add a new seller to seller_db
	 * @param  the seller entity which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addSeller(Seller seller){
//		CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");
//		Database db = dbClient.database("seller_db", true);
		 boolean flag = false;
	     Responses resp = db.save(seller);
	     if(resp.getId().equals(seller.getSellerId())){
	    	 flag = true;
	     }
	     return flag;
	}
	
	/**
	 * Remove a seller from seller_db
	 * @param the sellerid
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deleteSeller(String id){
		boolean flag = false;
		Seller seller = db.find(Seller.class, id);
		Responses resp = db.remove(seller);
		if(resp.getId().equals(id)){
	    	 flag = true;
	     }
		return flag;
	}
	
	/**
	 * Update a seller information to seller_db
	 * @param the new seller which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updateSeller(Seller newSeller){
		boolean flag = false;
		Seller seller = db.find(Seller.class,newSeller.getSellerId());
		seller.setDescription(newSeller.getDescription());
		seller.setEmail(newSeller.getEmail());
		seller.setExpireDate(newSeller.getExpireDate());
		seller.setLatitude(newSeller.getLatitude());
		seller.setLongtitude(newSeller.getLongtitude());
		seller.setName(newSeller.getName());
		seller.setPassword(newSeller.getPassword());
		seller.setTelNumber(newSeller.getTelNumber());
		Responses resp = db.update(seller);
		if(resp.getId().equals(seller.getSellerId())){
	    	 flag = true;
	     }
		return flag;
	}	
	
	/**
	 * find a seller from seller_db
	 * @param the sellerid
	 * @return the entity of the seller
	 * @author Tian
	 */
	public static Seller findSeller(String id){
		return db.find(Seller.class, id);
	}
	
	public static Seller login(String email, String password){
		
		Seller seller = new Seller(null, null, "null", 0, 0, null, null, null, null);
		seller = findSeller(email);
		
		 MD5 m = new MD5(); 
	     String pwdMD5 = m.getMD5ofStr(password);
	       
	       if(seller.getPassword().equals("null")){
	    	   return seller;
	       }else if(seller.getPassword().equals(pwdMD5)){
			  System.out.println("Login successfully");
			  return seller;
		   }else{
			  seller.setPassword("wrong");
			  return seller;
		   }
	}
	
}
