package sample.hello.cloudant;


import java.util.ArrayList;
import java.util.List;



import sample.hello.bean.Payment;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.Responses;

public class PaymentHandler {

	private static CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");

	private static Database db = dbClient.database("payment_db", true);

	/**
	 * Add a new Payment to payment_db
	 * @param  the Payment entity which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addPayment(Payment Payment){
		 boolean flag = false;
	     Responses resp = db.save(Payment);
	     if(resp.getId().equals(Payment.getTransactionId())){
	    	 flag = true;
	     }
	     return flag;
	}
	
	/**
	 * Remove a Payment from payment_db
	 * @param the transactionId
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deletePayment(String id){
		boolean flag = false;
		Payment Payment = db.find(Payment.class, id);
		Responses resp = db.remove(Payment);
		if(resp.getId().equals(id)){
	    	 flag = true;
	     }
		return flag;
	}
	
	/**
	 * Update a Payment information to payment_db
	 * @param the new Payment which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updatePayment(Payment newPayment){
		boolean flag = false;
		Payment Payment = db.find(Payment.class,newPayment.getTransactionId());

		Responses resp = db.update(Payment);
		if(resp.getId().equals(Payment.getTransactionId())){
	    	 flag = true;
	     }
		return flag;
	}	
	
	/**
	 * find a Payment from payment_db
	 * @param the transactionId
	 * @return the entity of the Payment
	 * @author Tian
	 */
	public static Payment findPaymentById(String id){
		return db.find(Payment.class, id);
	}
	
	public static List<Payment> findPaymentBySeller(){
		List<Payment> Payment = new ArrayList<Payment>();
		return Payment;
	}
}
