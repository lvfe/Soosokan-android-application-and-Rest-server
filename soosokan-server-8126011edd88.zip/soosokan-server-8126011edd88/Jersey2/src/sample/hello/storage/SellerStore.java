package sample.hello.storage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.sql.Date;

import sample.hello.bean.Seller;
import sample.hello.bean.ResultList;
import sample.hello.util.DBConnector;

/*
 * init store
 */
public class SellerStore {
	private int frequency=0;
	private static Map<String,Seller> store;
	private static SellerStore instance = null;
	
	public SellerStore() {
		store = new HashMap<String,Seller>();
		//initOneAd();
//		this.getAll();
	}
	
	public static Map<String,Seller> getStore() {
		if(instance==null) {
			instance = new SellerStore();
		}
		return store;
	}
	
	public boolean addSeller(Seller seller){
		
		  
		   Connection con;
		try {
			con = (Connection) new DBConnector().con();
			String tableName = "seller";
		       String sqlstr;
		       Statement stmt = (Statement) con.createStatement();
		       
		       String name=seller.getName();
	    	      String sellerId = seller.getSellerId();
	    	      String password=seller.getPassword();
	    	      float longtitude=seller.getLongtitude();
	    	      float latitude=seller.getLatitude();
	    	      String Semail = seller.getEmail();
	    	      String telnumber = seller.getTelNumber();
	    	      Date expireDate=seller.getExpireDate();

	    	      String description = seller.getDescription();
	       
	      
	       
	       sqlstr = "insert into "+tableName +" values ('"+name+"','"+sellerId+"','"+password+"',"+longtitude+","+latitude+",'"+
	    		   Semail+"','"+telnumber+"','"+expireDate+"','"+description+"')";
	       System.out.println(sqlstr);
	       int flag= stmt.executeUpdate(sqlstr);
		
	       System.out.println("add seller flag:" + flag);
	       store.put(seller.getSellerId(), seller);
	       System.out.println("add seller into store");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public boolean deleteSeller(String sellerID){
		
		  
		   Connection con;
		try {
			con = (Connection) new DBConnector().con();
		
	       String tableName = "seller";
	       String sqlstr;
	       Statement stmt = (Statement) con.createStatement();
	       
	       sqlstr = "delete from "+tableName +" where sellerId = '"+sellerID+"' ";
	       int flag= stmt.executeUpdate(sqlstr);
		
	       System.out.println("delete seller flag:" + flag);
	       store.remove(sellerID);
	       
	       System.out.println("delete seller from xml");
	       return true;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	public boolean updateSeller(Seller seller){
		Connection con;
		try {
			con = (Connection) new DBConnector().con();
		
	       String sqlstr;
	      
	       String name=seller.getName();
 	      String sellerId = seller.getSellerId();
 	      String password=seller.getPassword();
 	      float longtitude=seller.getLongtitude();
 	      float latitude=seller.getLatitude();
 	      String email = seller.getEmail();
 	      String telnumber = seller.getEmail();
 	      Date expireDate=seller.getExpireDate();

 	      String description = seller.getDescription();
	       
	       sqlstr = "update ads set name=?,password=?,longtitude=?,latitude=?,  email= ?, telnumber=?, expireDate=?, description=? where sellerId = ?";
	       PreparedStatement preparedStmt = con.prepareStatement(sqlstr);
	       preparedStmt.setString(1, name);
	       preparedStmt.setString(2, password);
	       preparedStmt.setFloat(3, longtitude);
	       preparedStmt.setFloat(4, latitude);
	       preparedStmt.setString(5, email);
	       preparedStmt.setString(6, telnumber);
	       preparedStmt.setDate(7, expireDate);
	       preparedStmt.setString(8, description);
	       preparedStmt.setString(9, sellerId);
	       
	       int flag= preparedStmt.executeUpdate();;
		
	       System.out.println("update seller flag:" + flag);
	       store.remove(seller.getSellerId());
	       store.put(seller.getSellerId(), seller);
	       System.out.println("update seller into xml");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public Seller getOneSeller(String sellerId){
		Connection con;
		Seller seller=null;
		try {
			con = (Connection) new DBConnector().con();
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT name, sellerId, password, longtitude, latitude,email, telnumber, expireDate, description from ads where sellerId= "+sellerId);
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       while (resultSet.next()) {
	    	   String name=resultSet.getString("name");
	    	      
	    	      String password=resultSet.getString("password");
	    	      Float longtitude=resultSet.getFloat("longtitde");
	    	      Float latitude=resultSet.getFloat("latitude");
	    	      String email=resultSet.getString("email");
	    	      String telnumber = resultSet.getString("telnumber");
	    	      Date expireDate=resultSet.getDate("expireDate");
	    	      String description = resultSet.getString("description");
	    	      sellerId = resultSet.getString("sellerId");
	    	      
	    	      seller=new Seller(name, sellerId, password,
		    	  			longtitude, latitude, email, telnumber,
		    				expireDate, description);
	    	    }
	      
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return seller;
	}
	
	public List<Seller> getAll(){
		Connection con;
		List<Seller> list=new ArrayList<Seller>();
		Seller seller=null;
		try {
			con = (Connection) new DBConnector().con();
			
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT adsId, sellerId, content, time, distance, bump from ads");
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       while (resultSet.next()) {
	    	   
	    	      String name=resultSet.getString("name");
	    	      String sellerId = resultSet.getString("sellerId");
	    	      String password=resultSet.getString("password");
	    	      float longtitude=resultSet.getFloat("longtitude");
	    	      float latitude=resultSet.getFloat("latitude");
	    	      String email = resultSet.getString("email");
	    	      String telnumber = resultSet.getString("telnumber");
	    	      Date expireDate=resultSet.getDate("expiredate");

	    	      String description = resultSet.getString("description");
	    	      seller=new Seller(name, sellerId, password,
	    	  			longtitude, latitude, email, telnumber,
	    				expireDate, description);
	    	      
	    	      list.add(seller);
	    	      store.put(sellerId, seller);
	    	     
	    	    }
	    	      
	    	   
	      
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	/*
	 * possible deplicate data
	 */
	public List<ResultList> searchSeller(List<String> word){
		
		List<ResultList> resultList=new ArrayList<ResultList>();
		Connection con;
		for(int i=0;i<word.size();i++){
			
		String currentWord=word.get(i);
		Seller seller=null;
		try {
			con = (Connection) new DBConnector().con();
			/*
			 * sql need changing.
			 */
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT name, sellerId, password, longtitude,latitude, email, telnumber,expiredate, description from ads where keyword= "+word);
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       
	       while (resultSet.next()) {
	    	   String name=resultSet.getString("name");
	    	      String sellerId = resultSet.getString("sellerId");
	    	      String password=resultSet.getString("password");
	    	      float longtitude=resultSet.getFloat("longtitude");
	    	      float latitude=resultSet.getFloat("latitude");
	    	      String email = resultSet.getString("email");
	    	      String telnumber = resultSet.getString("telnumber");
	    	      Date expireDate=resultSet.getDate("expiredate");

	    	      String description = resultSet.getString("description");
	    	      seller=new Seller(name, sellerId, password,
	    	  			longtitude, latitude, email, telnumber,
	    				expireDate, description);
	    	      
	    	    	  ResultList resultlist=new ResultList(seller,frequency);
	    		      resultList.add(resultlist);
	    	     
	    	    }
			      
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		}
		
		
		return resultList;
		
	}
	
}
