//package sample.hello.storage;
//
//import java.io.File;
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Timestamp;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Map.Entry;
//import org.codehaus.jettison.json.JSONObject;
//import org.apache.lucene.analysis.Analyzer;
//import org.apache.lucene.analysis.TokenStream;
//import org.apache.lucene.analysis.standard.StandardAnalyzer;
//import org.apache.lucene.document.Document;
//import org.apache.lucene.document.Field;
//import org.apache.lucene.document.Field.TermVector;
//import org.apache.lucene.index.DirectoryReader;
//import org.apache.lucene.index.IndexReader;
//import org.apache.lucene.index.IndexWriter;
//import org.apache.lucene.index.IndexWriterConfig;
//import org.apache.lucene.index.Term;
//import org.apache.lucene.index.IndexWriterConfig.OpenMode;
//import org.apache.lucene.queryparser.classic.QueryParser;
//import org.apache.lucene.sandbox.queries.DuplicateFilter;
//import org.apache.lucene.search.BooleanClause;
//import org.apache.lucene.search.BooleanQuery;
//import org.apache.lucene.search.FuzzyQuery;
//import org.apache.lucene.search.IndexSearcher;
//import org.apache.lucene.search.MatchAllDocsQuery;
//import org.apache.lucene.search.Query;
//import org.apache.lucene.search.ScoreDoc;
//import org.apache.lucene.search.Sort;
//import org.apache.lucene.search.SortField;
//import org.apache.lucene.search.TermQuery;
//import org.apache.lucene.search.TopDocs;
//import org.apache.lucene.search.TopScoreDocCollector;
//import org.apache.lucene.search.highlight.Formatter;
//import org.apache.lucene.search.highlight.Fragmenter;
//import org.apache.lucene.search.highlight.Highlighter;
//import org.apache.lucene.search.highlight.QueryScorer;
//import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
//import org.apache.lucene.search.highlight.SimpleSpanFragmenter;
//import org.apache.lucene.search.highlight.TokenSources;
//import org.apache.lucene.store.Directory;
//import org.apache.lucene.store.FSDirectory;
//import org.apache.lucene.util.Version;
//import org.wltea.analyzer.lucene.IKAnalyzer;
//
//
//
//@SuppressWarnings("deprecation")
//public class SearchStore {
//	private Directory dir;
//	private IndexWriterConfig iwc; 
//	private String indexPath;
//	private String docsPath;
//	private Analyzer analyzer;
//	private String field;
//	public SearchStore(){
//				indexPath = "c:\\s";
//		        docsPath = "C:\\s";
//		        field="C:\\s";
//		        Boolean create = false;
//		     final Path docDir = Paths.get(docsPath);
//		    if (!Files.isReadable(docDir)) {
//		      System.out.println("Document directory '" +docDir.toAbsolutePath()+ "' does not exist or is not readable, please check the path");
//		      System.exit(1);
//		    }
//		    System.out.println("Indexing to directory '" + indexPath + "'...");
//
//		      try {
//				dir = FSDirectory.open(new File(indexPath));
//			
//		      analyzer = new StandardAnalyzer(Version.LUCENE_40);
//		      iwc = new IndexWriterConfig(Version.LUCENE_40, analyzer);
//
//		      if (create) {
//		        // Create a new index in the directory, removing any
//		        // previously indexed documents:
//		        iwc.setOpenMode(OpenMode.CREATE);
//		      } else {
//		        // Add new documents to an existing index:
//		        iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
//		      }
//		      } catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//	}
//	public void indexItem(){
//		ItemStore itemStore=new ItemStore();
//		ResultSet rs=itemStore.searchByKeyword();
//		IndexWriter writer;
//		 Date start = new Date();
//		try {
//			writer = new IndexWriter(dir, iwc);
//		    Index_Item(writer,rs);
//	      int count =writer.numDocs();  
//	      writer.forceMerge(100);//�ϲ��������ļ�  
//	      
//
//	      writer.close();
//	      Date end = new Date();
//	      System.out.println(end.getTime() - start.getTime() + " total milliseconds");
//
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        
//      }
//	//��Ҫ�޸�	
//	private void Index_Item(IndexWriter writer, ResultSet rs) {
//		try {
//			while(rs.next()){
//			    Document doc=new Document();
//			    try {
//			    	Field Sellerid=new Field("Sellerid",rs.getString("Sellerid"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Name = new Field("Name", rs.getString("Name"), Field.Store.YES, Field.Index.NOT_ANALYZED, TermVector.NO);   
//			    	Field Keyword=new Field("Keyword",rs.getString("Keyword"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Price = new Field("Price", String.valueOf(rs.getFloat("Price")), Field.Store.YES, Field.Index.NOT_ANALYZED, TermVector.NO);   
//			    	Field ItemId=new Field("ItemId",rs.getString("ItemId"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//					Field Time=new Field("Time",String.valueOf(rs.getTimestamp("Time")),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	doc.add(Sellerid);
//					doc.add(Name);
//					doc.add(Keyword);
//					doc.add(Price);
//			    	doc.add(ItemId);
//					doc.add(Time);
//			    
//					writer.addDocument(doc);
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			  }
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
//
//
//private Float calcDistance(Float latitude, Float longitude, Float latitude1, Float longitude1){
//	Float calc=(float) 10000000.0;
//	calc=(float) java.lang.Math.sqrt((latitude-latitude1)*(latitude-latitude1)+(longitude-longitude1)*(longitude-longitude1));
//	return calc;
//}
//
//
//public void indexAds(){
//		AdsStore adsStore=new AdsStore();
//		ResultSet rs=adsStore.searchAd();
//		IndexWriter writer;
//		 Date start = new Date();
//		iwc.setOpenMode(OpenMode.CREATE);
//
//		 
//		try {
//			writer = new IndexWriter(dir, iwc);
//		    Index_Ads(writer,rs);
//	      int count =writer.numDocs();  
//	      writer.forceMerge(100);//�ϲ��������ļ�  
//	      
//
//	      writer.close();
//	      Date end = new Date();
//	      System.out.println(end.getTime() - start.getTime() + " total milliseconds");
//
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
////��Ҫ�޸�
//	private void Index_Ads(IndexWriter writer, ResultSet rs,JSONObject location) {
//		try {
//			while(rs.next()){
//			    Document doc=new Document();
//			    try {
//					Field AdsId=new Field("AdsId",rs.getString("AdsId"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Sellerid = new Field("Sellerid", rs.getString("Sellerid"), Field.Store.YES, Field.Index.NOT_ANALYZED, TermVector.NO);   
//			    	Field Content=new Field("Content",rs.getString("Content"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Distance = new Field("Distance", String.valueOf(rs.getInt("Distance")), Field.Store.YES, Field.Index.NOT_ANALYZED, TermVector.NO);   
//			    	Field Bump=new Field("Bump",String.valueOf(rs.getInt("Bump")),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Time=new Field("Time",String.valueOf(rs.getTimestamp("time")),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	doc.add(Distance);
//					doc.add(Bump);
//					doc.add(Content);
//					doc.add(Sellerid);
//			    	doc.add(AdsId);
//					doc.add(Time);
//			    
//					writer.addDocument(doc);
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			  }
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		
//	}
//	//changed�������˼����������
//	public void indexSeller(){
//		SellerStore sellerStore=new SellerStore();
//		ResultSet rs=sellerStore.searchSeller();
//		IndexWriter writer;
//		 Date start = new Date();
//		try {
//			writer = new IndexWriter(dir, iwc);
//		
//	     // indexDocs(writer, docDir);
//	      
//	      Index_Seller(writer,rs);
//	      int count =writer.numDocs();  
//	      writer.forceMerge(100);//�ϲ��������ļ�  
//	  
//
//	      writer.close();
//	      Date end = new Date();
//	      System.out.println(end.getTime() - start.getTime() + " total milliseconds");
//
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}	
//	}
//	
//	private void Index_Seller(IndexWriter writer, ResultSet rs,JSONObject location) {
//		Float currLat=location.get("latitude");
//		Float currLog=location.get("longitude");
//		try {
//			while(rs.next()){
//			    Document doc=new Document();
//			    try {
//			    	Field Name=new Field("Name",rs.getString("Name"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field SellerId = new Field("SellerId", rs.getString("SellerId"), Field.Store.YES, Field.Index.NOT_ANALYZED, TermVector.NO);   
//			    	Field Password=new Field("Password",rs.getString("Password"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Longtitude = new Field("Longtitude", String.valueOf(rs.getFloat("Longtitude")), Field.Store.YES, Field.Index.NOT_ANALYZED, TermVector.NO);   
//			    	Field Latitude=new Field("Latitude",String.valueOf(rs.getFloat("Latitude")),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Email=new Field("Email",rs.getString("Email"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Telnumber=new Field("Telnumber",rs.getString("Telnumber"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Expiredate=new Field("Expiredate",String.valueOf(rs.getDate("Expiredate")),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Field Description=new Field("Description",rs.getString("Description"),Field.Store.YES,Field.Index.NOT_ANALYZED,TermVector.NO);
//			    	Float a=calcDistance(rs.getFloat("Longtitude"),rs.getFloat("Latitude"),currLat,currLog);
//			    	Field Distance=new Field("Distance",String.valueOf(a), Field.Store.YES, Field.Index.NOT_ANALYZED, TermVector.NO);
//			    	
//			    	doc.add(Name);
//					doc.add(SellerId);
//					doc.add(Password);
//					doc.add(Longtitude);
//			    	doc.add(Latitude);
//					doc.add(Email);
//					doc.add(Telnumber);
//					doc.add(Expiredate);
//					doc.add(Description);
//					doc.add(Distance);
//			    
//					writer.addDocument(doc);
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			  }
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		
//	}
//	/*
//	 * �˴������⣬distance��Ҫ�������.cloudeant��λ�ȡseller��location
//	 */
//	public List<ResultList> searchItem(List<String> keywords,List<Integer> method, JSONObject location) throws Exception{
//		List<ResultList> list=new ArrayList<ResultList>();
//	    int repeat = 0;
//	    String queryString = null;
//	    int hitsPerPage = 10;
//
//			    IndexReader reader = DirectoryReader.open(FSDirectory.open(new File(indexPath)));
//			    IndexSearcher searcher = new IndexSearcher(reader);
//			    analyzer = new StandardAnalyzer(Version.LUCENE_40);
//String line="";
//			      for(int i=0;i<keywords.size();i++){
//			      line+=(keywords.get(i)+"~ ");
//			      System.out.println(keywords.get(i));}
//			      QueryParser parser = new QueryParser(Version.LUCENE_40, "Name", analyzer);
//			      Query query = parser.parse(line);
//			      
//			      BooleanQuery bq = new BooleanQuery();    
//		          TermQuery tq = new TermQuery(new Term("Keyword", line));    
//		          bq.add(tq, BooleanClause.Occur.MUST);   //can add multiple search
//		          
//		          bq.add(query,BooleanClause.Occur.MUST);
//		          DuplicateFilter df = new DuplicateFilter("topicId");    
//		          df.setProcessingMode(DuplicateFilter.ProcessingMode.PM_FAST_INVALIDATION);    
//		          
//		          SortField[] sortfield = null;
//			      sortfield = new SortField[] { SortField.FIELD_SCORE,   
//			    		  new SortField("CalDistance",SortField.Type.FLOAT,true) };  
//			      if(method.contains(1)) sortfield = new SortField[] { SortField.FIELD_SCORE,   
//			    		  new SortField("CalDistance",SortField.Type.FLOAT,true),new SortField("Time",SortField.Type.STRING,true) };
//			      if(method.contains(2)) sortfield = new SortField[] { SortField.FIELD_SCORE,   
//			    		  new SortField("CalDistance",SortField.Type.FLOAT,true),new SortField("Price",SortField.Type.FLOAT,true) };
//			    Sort sort = new Sort(sortfield);  
//			    		                
//			    		  TopDocs topDocs = searcher.search(bq, df, 100, sort);  
//			    		  System.out.println("������������" + topDocs.totalHits);  
//			    		  ScoreDoc[] hits = topDocs.scoreDocs;
//			      
//			              System.out.println("Found " + hits.length + " hits."); 
//			             
//			              for (int i = 0; i < hits.length; i++) {
//			                  Document hitDoc = reader.document(hits[i].doc);
//			              
//			          int docId = hits[i].doc;
//			          Document document = searcher.doc(docId);
//			         
//			          Item item=new Item();
//				    	 item.setItemId(document.get("ItemId"));
//				    	 item.setKeyword(document.get("Keyword"));
//				    	 item.setName(document.get("Name"));
//				    	 item.setSellerId(document.get("Sellerid"));
//				    	 item.setTime(Timestamp.valueOf(document.get("Time")));
//				    	 item.setPrice(Float.valueOf(document.get("Price")));
//				    	 ResultList rl=new ResultList(item,1);
//				    	 
//				    	 list.add(rl);
//				     }
//			     
//			      reader.close();
//					return list;
//			    }
//  
//
//	
//	
//	public List<ResultList> searchAds(List <String> keywords,List<Integer> method,JSONObject location) throws Exception{
//		List<ResultList> list=new ArrayList<ResultList>();
//	    int repeat = 0;
//	    String queryString = null;
//	    int hitsPerPage = 10;
//
//			    IndexReader reader = DirectoryReader.open(FSDirectory.open(new File(indexPath)));
//			    IndexSearcher searcher = new IndexSearcher(reader);
//			    analyzer = new StandardAnalyzer(Version.LUCENE_40);
//String line="";
//			      for(int i=0;i<keywords.size();i++){
//			      line+=(keywords.get(i)+"~ ");
//			      System.out.println(keywords.get(i));}
//			      QueryParser parser = new QueryParser(Version.LUCENE_40, "Content", analyzer);
//			      Query query = parser.parse(line);
//			      
//			      BooleanQuery bq = new BooleanQuery();    
//		          TermQuery tq = new TermQuery(new Term("content", line));    
//		        //  bq.add(tq, BooleanClause.Occur.MUST);   //can add multiple search
//		          
//		          bq.add(query,BooleanClause.Occur.MUST);
//		          DuplicateFilter df = new DuplicateFilter("topicId");    
//		          df.setProcessingMode(DuplicateFilter.ProcessingMode.PM_FAST_INVALIDATION);    
//		          SortField[] sortfield = null;
//			      
//			      sortfield = new SortField[] { SortField.FIELD_SCORE,   
//			    		  new SortField("Distance",SortField.Type.FLOAT,true) };  
//			      if(method.contains(1)) sortfield = new SortField[] { SortField.FIELD_SCORE,   
//			    		  new SortField("Distance",SortField.Type.FLOAT,true),new SortField("Time",SortField.Type.STRING,true) };
//			      if(method.contains(2)) sortfield = new SortField[] { SortField.FIELD_SCORE,   
//			    		  new SortField("Distance",SortField.Type.FLOAT,true),new SortField("Bump",SortField.Type.INT,true) };
//			    Sort sort = new Sort(sortfield);  
//			    		                
//			    		  TopDocs topDocs = searcher.search(bq, df, 100, sort);  
//			    		  System.out.println("������������" + topDocs.totalHits);  
//			    		  ScoreDoc[] hits = topDocs.scoreDocs;
//			      
//			              System.out.println("Found " + hits.length + " hits."); 
//			             
//			              for (int i = 0; i < hits.length; i++) {
//			                  Document hitDoc = reader.document(hits[i].doc);
//			              
//			          int docId = hits[i].doc;
//			          Document d = searcher.doc(docId);
//			         
//				    	 Ads ads=new Ads();
//				    	 ads.setAdsId(d.get("AdsId"));
//				    	 ads.setBump(Integer.valueOf(d.get("Bump")));
//				    	 ads.setContent(d.get("Content"));
//				    	 ads.setDistance(Integer.valueOf(d.get("Distance")));
//				    	 ads.setSellerID(d.get("SellerId"));
//				    	 ads.setTime(Timestamp.valueOf(d.get("Time")));
//				    	 
//				    	 ResultList rl=new ResultList(ads,1);
//				    	 list.add(rl);
//				     }
//			     
//			      reader.close();
//					return list;
//	}
//	
//	public List<ResultList> searchSeller(List<String> keywords,List<Integer> method,JSONObject location) throws Exception{
//		List<ResultList> list=new ArrayList<ResultList>();
//	    int repeat = 0;
//	    String queryString = null;
//	    int hitsPerPage = 10;
//
//			    IndexReader reader = DirectoryReader.open(FSDirectory.open(new File(indexPath)));
//			    IndexSearcher searcher = new IndexSearcher(reader);
//			    analyzer = new StandardAnalyzer(Version.LUCENE_40);
//String line="";
//			      for(int i=0;i<keywords.size();i++){
//			      line+=(keywords.get(i)+"~ ");
//			      System.out.println(keywords.get(i));}
//			      QueryParser parser = new QueryParser(Version.LUCENE_40, "Name", analyzer);
//			      Query query = parser.parse(line);
//			      
//			      BooleanQuery bq = new BooleanQuery();    
//		          TermQuery tq = new TermQuery(new Term("Descripyion", line));    
//		          bq.add(tq, BooleanClause.Occur.MUST);   //can add multiple search
//		          TermQuery tq1 = new TermQuery(new Term("Email", line));    
//		          bq.add(tq1, BooleanClause.Occur.MUST);   //can add multiple search
//		          TermQuery tq2 = new TermQuery(new Term("Telnumber", line));    
//		          bq.add(tq2, BooleanClause.Occur.MUST);   //can add multiple search
//		          bq.add(query,BooleanClause.Occur.MUST);
//		          DuplicateFilter df = new DuplicateFilter("topicId");    
//		          df.setProcessingMode(DuplicateFilter.ProcessingMode.PM_FAST_INVALIDATION);    
//		          SortField[] sortfield = null;
//			      
//			      sortfield = new SortField[] { SortField.FIELD_SCORE,   
//			    		  new SortField("Distance",SortField.Type.FLOAT,true) };  
//			      Sort sort = new Sort(sortfield);  
//			    		                
//			    		  TopDocs topDocs = searcher.search(bq, df, 100, sort);  
//			    		  System.out.println("������������" + topDocs.totalHits);  
//			    		  ScoreDoc[] hits = topDocs.scoreDocs;
//			      
//			              System.out.println("Found " + hits.length + " hits."); 
//			             
//			              for (int i = 0; i < hits.length; i++) {
//			                  Document hitDoc = reader.document(hits[i].doc);
//			              
//			          int docId = hits[i].doc;
//			          Document document = searcher.doc(docId);
//			         
//			          Seller seller=new Seller();
//				    	 seller.setDescription(document.get("Description"));
//				    	 seller.setEmail(document.get("Email"));
//				    	 
//				    	 DateFormat format=new SimpleDateFormat("MM-DD--YYYY");
//				    	 Date date=format.parse(document.get("ExpireDate"));
//				    	 seller.setExpireDate((java.sql.Date) date);
//				    	 
//				    	 seller.setLatitude(Float.valueOf(document.get("Latitude")));
//				    	 seller.setLongtitude(Float.valueOf(document.get("Longtitude")));
//				    	 seller.setName(document.get("Name"));
//				    	 seller.setPassword(document.get("Password"));
//				    	 seller.setTelNumber(document.get("Telnumber"));
//				    	 seller.setSellerId(document.get("SellerId"));
//				    	 ResultList rl=new ResultList(seller,1);
//				    	 
//				    	 list.add(rl);
//				     }
//			     
//			      reader.close();
//					return list;
//	
//
//
//	}
//	}
