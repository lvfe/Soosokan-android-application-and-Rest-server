package sample.hello.storage;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import sample.hello.bean.Seller;
import sample.hello.util.DBConnector;
import sample.hello.util.MD5;

public class LoginStore {

	@SuppressWarnings("null")
	public Seller login(String email, String password) throws SQLException, ClassNotFoundException, ParseException {
		// TODO Auto-generated method stub
		
		 Connection con = new DBConnector().con();
	       String sqlstr;
	       Statement stmt = con.createStatement();
	       ResultSet rs = null;
	           
	       String useremail = email;
	       sqlstr = "select * from seller where email = '"+useremail+"'; ";
	       rs = stmt.executeQuery(sqlstr);
	       String result = "";
	       Seller seller = new Seller(result, result, result, 0, 0, result, result, null, result);
	       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	      
//	       if(rs==null){
//	    	   seller.setPassword("null");
//	    	   return seller;
//	       }else{
	    	      while(rs.next()){
	  	    	    result = rs.getString("password");
	  	    	    seller.setName(rs.getString("name"));
	  	    	    seller.setSellerId(rs.getString("email"));
	  	    	    seller.setPassword("password");
	  	    	    seller.setLongtitude(Float.valueOf(rs.getString("longtitude")));
	  	    	    seller.setLatitude(Float.valueOf(rs.getString("latitude")));
	  	    	    seller.setEmail(rs.getString("email"));
	  	    	    seller.setTelNumber(rs.getString("telnumber"));
	  	    	    java.sql.Date date=java.sql.Date.valueOf(rs.getString("expireDate"));
	  	    	    seller.setExpireDate(date);
	  	    	    seller.setDescription(rs.getString("description"));
	  	       }
	  	       MD5 m = new MD5(); 
	  	       String pwdMD5 = m.getMD5ofStr(password);
	  	       
	  		   if(result.equals(pwdMD5)){
	  			  System.out.println("Login successfully");
	  			  return seller;
	  		   }else{
	  			  seller.setPassword("wrong");
	  			  return seller;
	  		   }
	    	   
//	       }
	 
	}

}
