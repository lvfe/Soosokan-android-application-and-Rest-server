package sample.hello.bean;

public class ResultList {
	Item item;
	Ads ads;
	Seller seller;
	int frequency;
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	
	public Ads getAds() {
		return ads;
	}
	public void setAds(Ads ads) {
		this.ads = ads;
	}
	
	public Seller getSeller() {
		return seller;
	}
	public void setSeller(Seller seller) {
		this.seller = seller;
	}
	
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public ResultList(Item item,  int frequency) {
		super();
		this.item = item;
		this.frequency = frequency;
	}
	
	public ResultList(Seller seller,  int frequency) {
		super();
		this.seller = seller;
		this.frequency = frequency;
	}
	
	public ResultList(Ads ads, int frequency) {
		super();
		this.ads = ads;
		this.frequency = frequency;
	}

}
