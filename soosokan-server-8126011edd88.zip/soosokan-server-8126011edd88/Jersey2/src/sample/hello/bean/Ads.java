package sample.hello.bean;


import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;

	@XmlRootElement
	public class Ads{
		private String _id;
		private String sellerID;
		private String title;
		private String description;
		private Timestamp time;
		private int distance;
		
		
		
		public Ads(String adsId, String sellerID, String title,
				String description, Timestamp time, int distance) {
			super();
			this._id = adsId;
			this.sellerID = sellerID;
			this.title = title;
			this.description = description;
			this.time = time;
			this.distance = distance;
		}

		public String getAdsId() {
			return _id;
		}

		public void setAdsId(String adsId) {
			this._id = adsId;
		}

		public String getSellerID() {
			return sellerID;
		}

		public void setSellerID(String sellerID) {
			this.sellerID = sellerID;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public Timestamp getTime() {
			return time;
		}

		public void setTime(Timestamp time) {
			this.time = time;
		}

		public int getDistance() {
			return distance;
		}

		public void setDistance(int distance) {
			this.distance = distance;
		}


//		private int bump;
		
		public Ads() {
			super();
			// TODO Auto-generated constructor stub
		}
		
	}

