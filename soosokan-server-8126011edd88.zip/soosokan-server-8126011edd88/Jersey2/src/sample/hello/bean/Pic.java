package sample.hello.bean;

import com.cloudant.client.api.model.Document;

public class Pic extends Document{
	private String pic;

	public Pic(String pic) {
		super();
		this.pic = pic;
	}

	public Pic() {
		super();
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	@Override
	public String toString() {
		return "Pic [pic=" + pic + "]";
	}
	

}
