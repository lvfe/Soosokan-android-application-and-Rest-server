//package sample.hello.resources;
//
//import java.sql.Date;
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.ws.rs.Consumes;
//import javax.ws.rs.DELETE;
//import javax.ws.rs.GET;
//import javax.ws.rs.Path;
//import javax.ws.rs.PathParam;
//import javax.ws.rs.Produces;
//import javax.ws.rs.core.MediaType;
//import javax.ws.rs.core.MultivaluedMap;
//
//
//
//import org.codehaus.jettison.json.JSONObject;
//
//import com.tt.ai.handler.WordHandler;
//
//import sample.hello.bean.ResultList;
//import sample.hello.bean.Seller;
//import sample.hello.storage.SearchStore;
//import sample.hello.storage.SellerStore;
//
//public class SearchResource {
//
//	@Path("/search")
//	public class SellerResource {
//		private SellerStore sellerstore=new SellerStore();
//		
//		
//		@GET
//		
//		@Path("/all")
//		@Produces(MediaType.APPLICATION_JSON)
//		public List<ResultList> searchAll(MultivaluedMap<String, String> wordParams) {
//			
//			JSONObject location=getLocation(wordParams);
//			String word=wordParams.getFirst("Keywords");
//			String numberString=wordParams.getFirst("Sort");
//			List<Integer> number=new ArrayList<Integer>();
//			for(int i=0;i<numberString.length();i++){
//				if(numberString.charAt(i)==1||numberString.charAt(i)==2)
//				number.add((int) numberString.charAt(i));
//			}
//			List<String> list=WordHandler.getPostList(word);
//			List<ResultList> list1=new ArrayList<ResultList>();
//			SearchStore searchStore=new SearchStore();
//			searchStore.indexItem(location);
//			searchStore.indexAds(location);
//			searchStore.indexSeller(location);
//			System.out.println("index ok");
//			try {
//				list1=list1=searchStore.searchItem(list,number,location);
//				list1.addAll(searchStore.searchStore(list,number,location));
//				list1.addAll(list1=searchStore.searchSeller(list,number,location));
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//				System.out.println("search ok");
//			
//			return list1;
//		}
//		
//		private JSONObject getLocation(MultivaluedMap<String, String> locationParams) {
//			String name = locationParams.getFirst("Name");
//		       Float latitude = Float.valueOf(locationParams.getFirst("Latitude"));
//		       Float longitude = Float.valueOf(locationParams.getFirst("Longitude"));
//		       //TimeStamp timestamp=
//		       JSONObject userLocation=new JSONObject();
//		       userLocation.put("name", name);
//		       userLocation.put("latitude", latitude);
//		       userLocation.put("longtitude", longitude);
//		       
//			return userLocation;
//		}
//
//		@GET
//		@Produces(MediaType.APPLICATION_JSON)
//		@Path("/ads")
//		public List<ResultList> searchAds(MultivaluedMap<String, String> wordParams) {
//			JSONObject location=getLocation(wordParams);
//			String word=wordParams.getFirst("Keywords");
//			String numberString=wordParams.getFirst("Sort");
//			List<Integer> number=new ArrayList<Integer>();
//			for(int i=0;i<numberString.length();i++){
//				if(numberString.charAt(i)==1||numberString.charAt(i)==2)
//				number.add((int) numberString.charAt(i));
//			}
//			List<String> list=WordHandler.getPostList(word);
//			List<ResultList> list1=new ArrayList<ResultList>();
//			SearchStore searchStore=new SearchStore();
//			searchStore.indexAds(location);
//			System.out.println("index ok");
//				list1=searchStore.searchAds(list,number,location);
//				System.out.println("search ok");
//			
//			return list1;
//		}
//		@GET
//		@Produces(MediaType.APPLICATION_JSON)
//		@Path("/seller")
//		public List<ResultList> searchSeller(MultivaluedMap<String, String> wordParams) {
//			
//			JSONObject location=getLocation(wordParams);
//				String word=wordParams.getFirst("Keywords");
//				String numberString=wordParams.getFirst("Sort");
//				List<Integer> number=new ArrayList<Integer>();
//				for(int i=0;i<numberString.length();i++){
//					if(numberString.charAt(i)==1||numberString.charAt(i)==2)
//					number.add((int) numberString.charAt(i));
//				}
//				List<String> list=WordHandler.getPostList(word);
//				List<ResultList> list1=new ArrayList<ResultList>();
//				SearchStore searchStore=new SearchStore();
//				searchStore.indexSeller(location);
//				System.out.println("index ok");
//					list1=searchStore.searchSeller(list,number,location);
//					System.out.println("search ok");
//				
//				return list1;
//		}
//		@GET
//		@Produces(MediaType.APPLICATION_JSON)
//		@Path("/item")
//		public List<ResultList> searchItem(MultivaluedMap<String, String> wordParams) {
//			
//			JSONObject location=getLocation(wordParams);
//				String word=wordParams.getFirst("Keywords");
//				String numberString=wordParams.getFirst("Sort");
//				List<Integer> number=new ArrayList<Integer>();
//				for(int i=0;i<numberString.length();i++){
//					if(numberString.charAt(i)==1||numberString.charAt(i)==2)
//					number.add((int) numberString.charAt(i));
//				}
//				List<String> list=WordHandler.getPostList(word);
//				List<ResultList> list1=new ArrayList<ResultList>();
//				SearchStore searchStore=new SearchStore();
//				searchStore.indexItem(location);
//				System.out.println("index ok");
//					list1=searchStore.searchItem(list,number,location);
//					System.out.println("search ok");
//				
//				return list1;
//		
//		
//		
//	}
//}
