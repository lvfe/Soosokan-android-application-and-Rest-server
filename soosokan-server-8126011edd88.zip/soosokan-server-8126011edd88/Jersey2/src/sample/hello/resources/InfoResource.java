//package sample.hello.resources;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//import java.sql.Statement;
//
//import javax.ws.rs.GET;
//import javax.ws.rs.POST;
//import javax.ws.rs.Path;
//import javax.ws.rs.Produces;
//import javax.ws.rs.core.MediaType;
//
//import sample.hello.bean.Item;
//import sample.hello.util.DBConnector;
//
//@Path("/info")
//public class InfoResource {
//	@GET
//	@Produces(MediaType.TEXT_PLAIN)
////	@POST
////	@Path("/loginClient")
////	@Produces(MediaType.APPLICATION_JSON)
//	public String sayHello() throws SQLException, ClassNotFoundException {
//		
//		String result = " info ";
//		   Connection con = new DBConnector().con();
//	       String tableName = "item";
//	       String sqlstr;
//	       Statement stmt = con.createStatement();
//	       ResultSet rs = null;
//	       String itemid = "aaa";
//	       String sql =  "select * from item where itemid= '"+itemid+"'; ";
//	//       sqlstr = "select * from "+tableName +"where itemid =aaa";
//	       rs = stmt.executeQuery(sql);
//	       
//	       Item item = new Item();
//	       ResultSetMetaData rsmd = rs.getMetaData();
//	       int j =rsmd.getColumnCount();
//	       
//	       while(rs.next()){
//	    	   
//	    	   String sellerid = rs.getString("sellerid");
//	    	   String name = rs.getString("name");
//	    	   String keyword = rs.getString("keyword");
//	    	   float price = Float.parseFloat(rs.getString("price"));
//	    	   String itemid1 = rs.getString("itemid");
//	    	   
//	    	   item.setItemId(itemid1);
//	    	   item.setSellerId(sellerid);
//	    	   item.setKeyword(keyword);
//	    	   item.setPrice(price);
//	    	   item.setName(name);
//	    	   
//	    	   for(int k = 0; k<j; k++)
//		       {
//		           result += rs.getString(k+1) + "\t";
//		           System.out.println(result);
//		       }
//	       }
//		System.out.println("info test");
//	//	return item;
//		return result;
//	}
//}
