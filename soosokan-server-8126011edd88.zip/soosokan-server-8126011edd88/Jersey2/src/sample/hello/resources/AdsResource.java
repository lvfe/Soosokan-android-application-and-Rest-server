package sample.hello.resources;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import sample.hello.bean.Ads;
import sample.hello.cloudant.AdsHandler;
//import sample.hello.storage.AdsStore;
import sample.hello.storage.AdsStore;

@Path("/ads")
public class AdsResource {
	private AdsStore adsstore=new AdsStore();
//	private AdsHandler adshandler = new AdsHandler();
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public boolean addItem(MultivaluedMap<String, String> adsParams) throws ClassNotFoundException {
		
//		   String adsId=adsParams.getFirst("adsId");
		   String adsId= "";
		   String sellerid = adsParams.getFirst("sellerId");
		   String title = adsParams.getFirst("title");
	       String description = adsParams.getFirst("description");
	       int distance = Integer.parseInt(adsParams.getFirst("distance"));
//	       int bump = Integer.parseInt(adsParams.getFirst("bump"));
	       
	       Date date = new Date();//���ϵͳʱ��.
	       String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���TimestampҪ��ĸ�ʽ.
	       Timestamp datetime = Timestamp.valueOf(nowTime);//��ʱ��ת��
	       
	       Ads ads = new Ads(adsId,sellerid,title, description,datetime,distance);
			
//	       return adshandler.addAds(ads);
			return adsstore.addAds(ads);
	}
	@DELETE
	@Path("/delete/{id}")
	public boolean deleteItem(@PathParam("ads") String ads){
		return adsstore.deleteAds(ads);
//		return adshandler.deleteAds(ads);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{ads}")
	public Ads getItem(@PathParam("ads") String ads) {
		return adsstore.getOneads(ads);
//		return adshandler.findAdsById(ads);
	}
	
	@PUT
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public boolean updateAds(Ads ads){
		return adsstore.updateAds(ads);
//		return adshandler.updateAds(ads);
	}
}
