package sample.hello.resources;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;






import sample.hello.bean.Ads;
import sample.hello.bean.Seller;
import sample.hello.bean.ResultList;
import sample.hello.cloudant.AdsHandler;
import sample.hello.cloudant.SellerHandler;
import sample.hello.storage.SellerStore;
import sample.hello.util.MD5;

@Path("/seller")
public class SellerResource {
	private SellerStore sellerstore=new SellerStore();
	private SellerHandler sellerhandler = new SellerHandler();
	@Path("/add")
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public boolean addSeller(MultivaluedMap<String, String> sellerParams) throws ClassNotFoundException {
			System.out.println("add seller!");
	       String email = sellerParams.getFirst("email");
		   String name=sellerParams.getFirst("name");
		   String sellerId = email;
	       String password = sellerParams.getFirst("password");
	       
	       MD5 m = new MD5(); 
	       String pwdMD5 = m.getMD5ofStr(password);
	       
	       Float longtitude=Float.parseFloat(sellerParams.getFirst("longtitude"));
	       Float latitude=Float.parseFloat(sellerParams.getFirst("latitude"));
	       String telnumber = sellerParams.getFirst("telnumber");
	       Date date=new Date(new java.util.Date().getTime()); 
	       date.setMonth(date.getMonth()+1);
	       Date expiredate = date;
	       String description=sellerParams.getFirst("description");
	       Seller seller = new Seller(name, sellerId, pwdMD5,
	   			longtitude, latitude, email, telnumber,
				expiredate, description);
//		   return	sellerstore.addSeller(seller);
	       return sellerhandler.addSeller(seller);
	}
	@DELETE
	@Path("/delete/{id}")
	public boolean deleteSeller(@PathParam("sellerId") String sellerId){
		return sellerstore.deleteSeller(sellerId);
//		return sellerhandler.deleteSeller(sellerId);
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Seller> getSeller() {
		return sellerstore.getAll();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/search")
	public List<ResultList> searchSeller(MultivaluedMap<String, String> wordParams) {
		String word=wordParams.getFirst("word");
		List<String> wordArray=new ArrayList<String>();
		wordArray.add(word);
		
		List<ResultList> resultList=new ArrayList<ResultList>();
		resultList=sellerstore.searchSeller(wordArray);
		return resultList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{seller}")
	public Seller getOneSeller(
			@PathParam("seller") String seller) {
//		return sellerhandler.findSeller(seller);
		return sellerstore.getOneSeller(seller);
	}
	
	@PUT
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public boolean updateSeller(Seller seller){
//		return sellerhandler.updateSeller(seller);
		return sellerstore.updateSeller(seller);
	}
}

