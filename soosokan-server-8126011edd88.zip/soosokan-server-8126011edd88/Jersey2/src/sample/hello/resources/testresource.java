package sample.hello.resources;

import sample.hello.bean.Seller;
import sample.hello.cloudant.SellerHandler;

public class testresource {

	public boolean addtest(Seller seller){
		
		return SellerHandler.addSeller(seller);
		
	}
}
