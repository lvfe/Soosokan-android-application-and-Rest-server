package sample.hello.resources;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.mysql.fabric.xmlrpc.base.Data;

import sample.hello.util.DBConnector;

@Path("/addItem")
public class ItemAddResource {
	@GET
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public boolean addItem(MultivaluedMap<String, String> itemParams) throws SQLException, ClassNotFoundException {
		
		  
		   Connection con = new DBConnector().con();
	       String tableName = "item";
	       String sqlstr;
	       Statement stmt = con.createStatement();
	       
	       String sellerid = itemParams.getFirst("sellerId");
	       String name = itemParams.getFirst("name");
	       String keyword = itemParams.getFirst("keyword");
	       float price = Float.parseFloat(itemParams.getFirst("price"));
	       String itemid = itemParams.getFirst("itemId");
	       
	       Date date = new Date();//���ϵͳʱ��.
	       String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���TimestampҪ��ĸ�ʽ.
	       Timestamp datetime = Timestamp.valueOf(nowTime);//��ʱ��ת��
	       

	       sqlstr = "insert into "+tableName +" values ("+sellerid+","+name+","+keyword+","
	    		   	+price+","+itemid+","+datetime+")";
	       int flag= stmt.executeUpdate(sqlstr);
		
	       System.out.println("add item flag:" + flag);
		return true;
	}
}
