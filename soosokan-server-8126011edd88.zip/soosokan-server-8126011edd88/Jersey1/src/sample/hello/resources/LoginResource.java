package sample.hello.resources;
import java.sql.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import sample.hello.bean.Seller;
import sample.hello.storage.LoginStore;
import sample.hello.util.DBConnector;

@Path("/login")
public class LoginResource {
	private final static String USERNAME = "userName";
	private final static String PASSWORD = "password";
	private LoginStore loginstore= new LoginStore();
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public String Login(MultivaluedMap<String, String> userParams) throws ClassNotFoundException, SQLException{
			String userName = userParams.getFirst(USERNAME);
			String password = userParams.getFirst(PASSWORD);
	
			System.out.println(userName);
			System.out.println(password);
			
			boolean flag = loginstore.login(userName,password);
			
			if(flag){
				return "login successfully!";
			}else{
				return "wrong password! or No user!";
			}
		}
}

