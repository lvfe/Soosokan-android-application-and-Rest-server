package sample.hello.resources;
import java.sql.*;

import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import sample.hello.bean.Seller;
import sample.hello.util.DBConnector;

@Path("/test")
public class LoginTest {
//	@Path("logintest/{password}")
//	@GET
//	public boolean Login(@PathParam("password") String password) {
//		if(password.equals("123456")){
//			return true;
//		}else{
//			return false;
//		}
//		}
	private final static String FIRSTNAME = "firstName";
	private final static String LASTNAME = "lastName";
	private final static String USERNAME = "userName";
	private final static String PASSWORD = "password";

	
	@POST
	@Path("/loginClient")
//	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
//	public String loginUser(MultivaluedMap<String, String> userParams) {
//		String response="";
//		String userName = userParams.getFirst(USERNAME);
//		String password = userParams.getFirst(PASSWORD);
//
//		System.out.println(userName);
//		System.out.println(password);
//		//add to userOnline list
//		
//		response="Login Successful";
//		return response;
//	}
	
	//return Json data
	public Seller loginUser() {

		Seller user = new Seller();
		user.setPassword("123456");
		user.setName("new");
		System.out.println("login json");
		return user;
		
	}
}

