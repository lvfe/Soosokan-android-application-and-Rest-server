package sample.hello.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;



import sample.hello.bean.Ads;
import sample.hello.storage.AdsStore;

@Path("/ads")
public class AdsResource {
	private AdsStore adsstore=new AdsStore();

	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public boolean addItem(MultivaluedMap<String, String> adsParams) throws ClassNotFoundException {
		
		   String adsId=adsParams.getFirst("adsId");
		   String sellerid = adsParams.getFirst("sellerId");
	       String content = adsParams.getFirst("content");
	       int distance = Integer.parseInt(adsParams.getFirst("distance"));
	       int bump = Integer.parseInt(adsParams.getFirst("bump"));
	       Ads ads = new Ads(adsId,sellerid, content,distance,bump);
			adsstore.addAds(ads);
			System.out.println("add this ads");
		return true;
	}
	@DELETE
	@Path("/delete/{id}")
	public boolean deleteItem(@PathParam("ads") String ads){
		adsstore.deleteAds(ads);
		System.out.println("delete this ads");
		return true;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{ads}")
	public Ads getItem(
			@PathParam("ads") String ads) {
		return adsstore.getOneads(ads);
	}
	
	@PUT
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public boolean updateAds(Ads ads){
		adsstore.updateAds(ads);
		System.out.println("update this ads");
		return true;
		
	}
}
