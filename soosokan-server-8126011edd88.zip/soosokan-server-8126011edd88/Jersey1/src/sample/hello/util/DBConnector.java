package sample.hello.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {
	
	public Connection con() throws ClassNotFoundException, SQLException{
		String user = "root";
	    String password = "123456";
	    String url = "jdbc:mysql://localhost:3306/soo";
	    String driver = "com.mysql.jdbc.Driver";
	    Connection con = null;
	    
	    Class.forName(driver);
	    con = DriverManager.getConnection(url, user, password);
	    
	    return con;
	}
}
