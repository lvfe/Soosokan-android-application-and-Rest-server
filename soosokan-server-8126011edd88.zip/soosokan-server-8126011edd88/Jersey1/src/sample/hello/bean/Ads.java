package sample.hello.bean;


import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;

	@XmlRootElement
	public class Ads{
		private String adsId;
		private String sellerID;
		private String content;
		private Timestamp time;
		private int distance;
		private int bump;
		
		public Ads() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Ads(String adsId, String sellerID, String content, Timestamp time,
				int distance, int bump) {
			super();
			this.adsId = adsId;
			this.sellerID = sellerID;
			this.content = content;
			this.distance = distance;
			this.time=time;
			this.bump = bump;
		}
		
		public Ads(String adsId, String sellerID, String content, 
				int distance, int bump) {
			super();
			this.adsId = adsId;
			this.sellerID = sellerID;
			this.content = content;
			this.distance = distance;
			this.bump = bump;
		}
		
		@Override
		public int hashCode() {
			// TODO Auto-generated method stub
			return super.hashCode();
		}
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return super.toString();
		}
		public String getAdsId() {
			return adsId;
		}
		public void setAdsId(String adsId) {
			this.adsId = adsId;
		}
		public String getSellerID() {
			return sellerID;
		}
		public void setSellerID(String sellID) {
			this.sellerID = sellID;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public Timestamp getTime() {
			return time;
		}
		public void setTime(Timestamp time) {
			this.time = time;
		}
		public int getDistance() {
			return distance;
		}
		public void setDistance(int distance) {
			this.distance = distance;
		}
		public int getBump() {
			return bump;
		}
		public void setBump(int bump) {
			this.bump = bump;
		}
		
		
		
	}

