package sample.hello.storage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import sample.hello.util.DBConnector;

public class LoginStore {

	public boolean login(String userName, String password) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		 Connection con = new DBConnector().con();
	       String sqlstr;
	       Statement stmt = con.createStatement();
	       ResultSet rs = null;
	           
	       String sellerid = userName;
	       sqlstr = "select password from seller where sellerid = '"+sellerid+"'; ";
	       rs = stmt.executeQuery(sqlstr);
	       String result = "";
	       
	       
	       while(rs.next()){
	    	   result = rs.getString("password");
	       }
	       
		   if(result.equals(password)){
			  System.out.println("Login successfully");
			  return true;
		   }else{
			  return false;
		   }
	}

}
