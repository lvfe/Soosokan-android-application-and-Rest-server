package sample.hello.storage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sample.hello.bean.Ads;
import sample.hello.util.DBConnector;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;



/*
 * init store
 */
public class AdsStore {
	private static Map<String,Ads> store;
	private static AdsStore instance = null;
	
	public AdsStore() {
		store = new HashMap<String,Ads>();
		//initOneAd();
		this.getAll();
	}
	
	public static Map<String,Ads> getStore() {
		if(instance==null) {
			instance = new AdsStore();
		}
		return store;
	}
	
	private void initOneAd() {
		Timestamp time=new Timestamp(System.currentTimeMillis());
		Ads firstAd = new Ads("adsId", "sellID", "content",time, 
				20, 0);
		addAds(firstAd);
		
	}
	public boolean addAds(Ads ads){
		
		  
		   Connection con;
		try {
			con = (Connection) new DBConnector().con();
			String tableName = "ads";
		       String sqlstr;
		       Statement stmt = (Statement) con.createStatement();
		
	       
	      
			String adsId=ads.getAdsId();
	       String sellerId = ads.getSellerID();
	       String content = ads.getContent();
	       int distance = ads.getDistance();
	       int bump = ads.getBump();
//	       Date date = new Date();//���ϵͳʱ��.
//	       String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���TimestampҪ��ĸ�ʽ.
//	       Timestamp datetime = Timestamp.valueOf(nowTime);//��ʱ��ת��
//	       ads.setTime(datetime);
//	       System.out.println(datetime);
	       sqlstr = "insert into "+tableName +" values ('"+adsId+"','"+sellerId+"','"+content+"',"
	    		   	+"null,"+distance+","+bump+")";
	       System.out.println(sqlstr);
	       int flag= stmt.executeUpdate(sqlstr);
		
	       System.out.println("add ads flag:" + flag);
	       store.put(ads.getAdsId(), ads);
	       System.out.println("add ads into xml");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public boolean deleteAds(String adsID){
		
		  
		   Connection con;
		try {
			con = (Connection) new DBConnector().con();
		
	       String tableName = "ads";
	       String sqlstr;
	       Statement stmt = (Statement) con.createStatement();
	       
	       sqlstr = "delete from "+tableName +" where adsId = "+adsID+" ";
	       int flag= stmt.executeUpdate(sqlstr);
		
	       System.out.println("delete ads flag:" + flag);
	       store.remove(adsID);
	       
	       System.out.println("delete ads from xml");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public boolean updateAds(Ads ads){
		Connection con;
		try {
			con = (Connection) new DBConnector().con();
		
	       String sqlstr;
	      
	       String sellerID = ads.getSellerID();
	       String content = ads.getContent();
	       int distance = ads.getDistance();
	       int bump = ads.getBump();
	       
	       Date date = new Date();//���ϵͳʱ��.
	       String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���TimestampҪ��ĸ�ʽ.
	       Timestamp datetime = Timestamp.valueOf(nowTime);//��ʱ��ת��
	       
	       sqlstr = "update ads set sellerid = ?,  content= ?, distance=?, bump=?, time=? where adsId = ?";
	       PreparedStatement preparedStmt = con.prepareStatement(sqlstr);
	       preparedStmt.setString(1, sellerID);
	       preparedStmt.setString(2, content);
	       preparedStmt.setInt(3, distance);
	       preparedStmt.setInt(4, bump);
	       preparedStmt.setTimestamp(5, datetime);
	       preparedStmt.setString(6, ads.getAdsId());
	       
	       int flag= preparedStmt.executeUpdate();;
		
	       System.out.println("update ads flag:" + flag);
	       store.remove(ads.getAdsId());
	       store.put(ads.getAdsId(), ads);
	       System.out.println("update ads into xml");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public Ads getOneads(String adsId){
		Connection con;
		Ads ads=null;
		try {
			con = (Connection) new DBConnector().con();
			ads=new Ads();
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT adsId, sellerID, content, time, distance, bump from ads where adsId= "+adsId);
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       while (resultSet.next()) {
	    	      String sellerId = resultSet.getString("sellerID");
	    	      String content = resultSet.getString("content");
	    	      Timestamp time=resultSet.getTimestamp("time");

	    	      int distance = resultSet.getInt("distance");
	    	      int bump = resultSet.getInt("bump");
	    	      ads.setAdsId(adsId);
	    	      ads.setTime(time);
	    	      ads.setBump(bump);
	    	      ads.setContent(content);
	    	      ads.setDistance(distance);
	    	      ads.setSellerID(sellerId);
	    	    }
	      
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ads;
	}
	public List getAll(){
		Connection con;
		List<Ads> list=new ArrayList<Ads>();
		Ads ads=null;
		try {
			con = (Connection) new DBConnector().con();
			
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT adsId, sellerId, content, time, distance, bump from ads");
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       while (resultSet.next()) {
	    	   ads=new Ads();
	    	   String adsId = resultSet.getString("adsId");
	    	      String sellerId = resultSet.getString("sellerId");
	    	      String content = resultSet.getString("content");
	    	      int bump = resultSet.getInt("bump");
	    	      int distance = resultSet.getInt("distance");
	    	      Timestamp time=resultSet.getTimestamp("time");
	    	      ads.setAdsId(adsId);
	    	      ads.setTime(time);
	    	      ads.setBump(bump);
	    	      ads.setContent(content);
	    	      ads.setDistance(distance);
	    	      ads.setSellerID(sellerId);
	    	      list.add(ads);
	    	      store.put(adsId, ads);
	    	    }
	      
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
