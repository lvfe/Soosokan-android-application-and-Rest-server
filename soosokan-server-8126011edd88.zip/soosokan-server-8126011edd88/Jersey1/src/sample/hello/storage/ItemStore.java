package sample.hello.storage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import sample.hello.bean.Item;
import sample.hello.util.DBConnector;

public class ItemStore {
	private Map<String,Item> store;
	private ItemStore instance = null;
	
	public ItemStore() {
		store = new HashMap<String,Item>();
		getAll();
	}
	public Map<String,Item> getStore() {
		if(instance==null) {
			instance = new ItemStore();
		}
		return store;
	}
	
	Date date = new Date();//���ϵͳʱ��.
    String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���TimestampҪ��ĸ�ʽ.
    Timestamp datetime = Timestamp.valueOf(nowTime);//��ʱ��ת��
    
	private void initOneItem() {
		Item firstItem = new Item("itemId", "sellerId", "name","keyword",1, datetime);
		addItem(firstItem);
		store.put(firstItem.getItemId(), firstItem);
	}
	public boolean addItem(Item item){
		
		System.out.println("add item db");
		   Connection con;
		try {
			con = (Connection) new DBConnector().con();
		
	       String tableName = "item";
	       String sqlstr;
	       Statement stmt = (Statement) con.createStatement();
	       String sellerid = item.getSellerId();
	       String name = item.getName();
	       String keyword = item.getKeyword();
	       float price = item.getPrice();
	       String itemid = item.getItemId();
	       Timestamp datetime = item.getTime();
	       
	       sqlstr = "insert into "+tableName +" values ('"+sellerid+"','"+name+"','"+keyword+"',"
	    		   	+price+",'"+itemid+"','"+datetime+"')";
	       System.out.println(sqlstr);
	       int flag= stmt.executeUpdate(sqlstr);
		
	       System.out.println("add item flag:" + flag);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public boolean deleteItem(String itemID){
		   Connection con;
		try {
			con = (Connection) new DBConnector().con();
		
	       String tableName = "item";
	       String sqlstr;
	       Statement stmt = (Statement) con.createStatement();
	       
	       sqlstr = "delete from "+tableName +" where itemId = "+itemID+" ";
	       int flag= stmt.executeUpdate(sqlstr);
		
	       System.out.println("delete item flag:" + flag);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public boolean updateItem(Item item){
		Connection con;
		try {
			con = (Connection) new DBConnector().con();
		
	       String sqlstr;
	       String sellerid = item.getSellerId();
	       String name = item.getName();
	       String keyword = item.getKeyword();
	       float price = item.getPrice();
	       String itemid = item.getItemId();
	       
	       Date date = new Date();//���ϵͳʱ��.
	       String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���TimestampҪ��ĸ�ʽ.
	       Timestamp datetime = Timestamp.valueOf(nowTime);//��ʱ��ת��
	       
	       sqlstr = "update item set sellerid = ?,  name= ?, keyword=?, price=?, time=? where itemId = ?";
	       PreparedStatement preparedStmt = con.prepareStatement(sqlstr);
	       preparedStmt.setString(1, sellerid);
	       preparedStmt.setString(2, name);
	       preparedStmt.setString(3, keyword);
	       preparedStmt.setFloat(4, price);
	       preparedStmt.setTimestamp(5, datetime);
	       preparedStmt.setString(6, itemid);
	       
	       int flag= preparedStmt.executeUpdate();;
		
	       System.out.println("add item flag:" + flag);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public Item getOneItem(String itemId){
		Connection con;
		Item item=null;
		try {
			con = (Connection) new DBConnector().con();
			item=new Item();
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT sellerId, name, keyword, price, time from item where itemId= "+itemId);
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       while (resultSet.next()) {
	    	      String sellerId = resultSet.getString("sellerId");
	    	      String name = resultSet.getString("name");
	    	      String keyword = resultSet.getString("keyword");
	    	      Float price = resultSet.getFloat("price");
	    	      Timestamp time=resultSet.getTimestamp("time");
	    	      item.setItemId(itemId);
	    	      item.setKeyword(keyword);
	    	      item.setName(name);
	    	      item.setPrice(price);
	    	      item.setSellerId(sellerId);
	    	      item.setTime(time);
	    	    }
	      
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return item;
	}
	public List<Item> searchByKeyword(String keyword){
		Connection con;
		List<Item> list=new ArrayList<Item>();
		Item item=null;
		try {
			con = (Connection) new DBConnector().con();
			
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT itemId, sellerId, name, keyword, price, time from item where keyword= "+keyword);
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       while (resultSet.next()) {
	    	   item=new Item();
	    	   String itemId = resultSet.getString("itemId");
	    	      String sellerId = resultSet.getString("sellerId");
	    	      String name = resultSet.getString("name");
	    	      keyword = resultSet.getString("keyword");
	    	      Float price = resultSet.getFloat("price");
	    	      Timestamp time=resultSet.getTimestamp("time");
	    	      item.setItemId(itemId);
	    	      item.setKeyword(keyword);
	    	      item.setName(name);
	    	      item.setPrice(price);
	    	      item.setSellerId(sellerId);
	    	      item.setTime(time);
	    	      list.add(item);
	    	    }
	      
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public List<Item> getAll(){
		Connection con;
		List<Item> list=new ArrayList<Item>();
		Item item=null;
		try {
			con = (Connection) new DBConnector().con();
			
	       PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement("SELECT itemId, sellerId, name, keyword, price, time from item");
	       ResultSet     resultSet = preparedStatement.executeQuery();
	       while (resultSet.next()) {
	    	   item=new Item();
	    	   String itemId = resultSet.getString("itemId");
	    	      String sellerId = resultSet.getString("sellerId");
	    	      String name = resultSet.getString("name");
	    	      String keyword = resultSet.getString("keyword");
	    	      Float price = resultSet.getFloat("price");
	    	      Timestamp time=resultSet.getTimestamp("time");
	    	      item.setItemId(itemId);
	    	      item.setKeyword(keyword);
	    	      item.setName(name);
	    	      item.setPrice(price);
	    	      item.setSellerId(sellerId);
	    	      item.setTime(time);
	    	      list.add(item);
	    	    }
	      
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
