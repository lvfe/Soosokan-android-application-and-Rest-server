package Clondant.soosokan.handler;

import java.util.ArrayList;
import java.util.List;

import Cloudant.soosokan.entity.Payment;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.IndexField;
import com.cloudant.client.api.model.IndexField.SortOrder;
import com.cloudant.client.api.model.Response;

public class PaymentHandler {

	private static CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");

	private static Database db = dbClient.database("payment_db", true);
	
	/**
	 * Create a Index by sellerId
	 * Index is sellerId
	 * Do not need update
	 * @author Tian
	 */
	public static void CreateIndexBySellerId(){
		db.createIndex("sellerId", "sellerId", null,
				new IndexField[]{
				new IndexField("sellerId", SortOrder.asc),
				new IndexField("_id", SortOrder.asc)});
	}

	/**
	 * Add a new Payment to payment_db
	 * @param  the Payment entity which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addPayment(Payment Payment){
		 boolean flag = false;
	     Response resp = db.save(Payment);
	     if(resp.getId().equals(Payment.getTransactionId())){
	    	 flag = true;
	     }
	     return flag;
	}
	
	/**
	 * Remove a Payment from payment_db
	 * @param the transactionId
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deletePayment(String id){
		boolean flag = false;
		Payment Payment = db.find(Payment.class, id);
		Response resp = db.remove(Payment);
		if(resp.getId().equals(id)){
	    	 flag = true;
	     }
		return flag;
	}
	
	/**
	 * Update a Payment information to payment_db
	 * @param the new Payment which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updatePayment(Payment newPayment){
		boolean flag = false;
		Payment Payment = db.find(Payment.class,newPayment.getTransactionId());

		Response resp = db.update(Payment);
		if(resp.getId().equals(Payment.getTransactionId())){
	    	 flag = true;
	     }
		return flag;
	}	
	
	/**
	 * find a Payment from payment_db
	 * @param the transactionId
	 * @return the entity of the Payment
	 * @author Tian
	 */
	public static Payment findPaymentById(String id){
		return db.find(Payment.class, id);
	}
	
	/**
	 * Find the Payment by SellerId
	 * @param SellerId is the id of the seller
	 * @return List<Payment> The Payment list which sellerId is match the para
	 */
	public static List<Payment> findPaymentBySeller(String sellerId){
		List<Payment> Payment = new ArrayList<Payment>();
		String find = "\"selector\": {  \"name\": \""+sellerId+"\" }";
		Payment = db.findByIndex(find
				, Payment.class);
		return Payment;
	}
	
}
