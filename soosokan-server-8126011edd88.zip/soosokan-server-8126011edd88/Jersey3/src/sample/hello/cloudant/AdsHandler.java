package Clondant.soosokan.handler;

import java.util.ArrayList;
import java.util.List;

import Cloudant.soosokan.entity.Ads;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.IndexField;
import com.cloudant.client.api.model.IndexField.SortOrder;
import com.cloudant.client.api.model.Response;

public class AdsHandler {
	private static CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");

	private static Database db = dbClient.database("ads_db", true);
	
	
	/**
	 * Create a Index by sellerId
	 * Index is sellerId
	 * Do not need update
	 * @author Tian
	 */
	public static void CreateIndexBySellerId(){
		db.createIndex("sellerId", "sellerId", null,
				new IndexField[]{
				new IndexField("sellerId", SortOrder.asc),
				new IndexField("time", SortOrder.asc)});
	}

	/**
	 * Add a new Ads to ads_db
	 * @param  the Ads entity which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addAds(Ads Ads){
		 boolean flag = false;
	     Response resp = db.save(Ads);
	     if(resp.getId().equals(Ads.getAdsId())){
	    	 flag = true;
	     }
	     return flag;
	}
	
	/**
	 * Remove a Ads from ads_db
	 * @param the Adsid
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deleteAds(String id){
		boolean flag = false;
		Ads Ads = db.find(Ads.class, id);
		Response resp = db.remove(Ads);
		if(resp.getId().equals(id)){
	    	 flag = true;
	     }
		return flag;
	}
	
	/**
	 * Update a Ads information to ads_db
	 * @param the new Ads which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updateAds(Ads newAds){
		boolean flag = false;
		Ads ads = db.find(Ads.class,newAds.getAdsId());
		ads.setBump(newAds.getBump());
		ads.setContent(newAds.getContent());
		ads.setDistance(newAds.getDistance());
		ads.setTime(newAds.getTime());
		Response resp = db.update(ads);
		if(resp.getId().equals(ads.getAdsId())){
	    	 flag = true;
	     }
		return flag;
	}	
	
	/**
	 * find a Ads from ads_db
	 * @param the Adsid
	 * @return the entity of the Ads
	 * @author Tian
	 */
	public static Ads findAdsById(String id){
		return db.find(Ads.class, id);
	}
	
	/**
	 * Find the Ads by SellerId
	 * @param SellerId is the id of the seller
	 * @return List<Asa> The Ads list which sellerId is match the para
	 */
	public static List<Ads> findAdsBySeller(String sellerId){
		List<Ads> Ads = new ArrayList<Ads>();
		String find = "\"selector\": {  \"name\": \""+sellerId+"\" }";
		Ads = db.findByIndex(find
				, Ads.class);
		return Ads;
	}
	

}
