package Clondant.soosokan.handler;

import java.util.ArrayList;
import java.util.List;

import Cloudant.soosokan.entity.Item;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.IndexField;
import com.cloudant.client.api.model.IndexField.SortOrder;
import com.cloudant.client.api.model.Response;

public class ItemHandler {
	private static CloudantClient dbClient = new CloudantClient("soosokan",
			"soosokan", "soosokan1");

	private static Database db = dbClient.database("item_db", true);
	
	/**
	 * Create a Index by sellerId
	 * Index is sellerId
	 * Do not need update
	 * @author Tian
	 */
	public static void CreateIndexBySellerId(){
		db.createIndex("sellerId", "sellerId", null,
				new IndexField[]{
				new IndexField("sellerId", SortOrder.asc),
				new IndexField("name", SortOrder.asc)});
	}
	
	/**
	 * Create a Index by item name
	 * Index is sellerId
	 * Do not need update
	 * @author Tian
	 */
	public static void CreateIndexByName(){
		db.createIndex("name", "name", null,
				new IndexField[]{
				new IndexField("sellerId", SortOrder.asc)
				});
	}

	/**
	 * Add a new item to item_db
	 * 
	 * @param item
	 *            entity which contains the information needs to update
	 * @param filePath
	 *            of the picture
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addItem(Item item) {
		boolean flag = false;
		//item.setPicId(PictureHandler.savePic(filePath, item.getItemId()));
		Response resp = db.save(item);
		if (resp.getId().equals(item.getItemId())) {
			flag = true;
		}
		return flag;
	}

	/**
	 * Remove a item from item_db
	 * 
	 * @param id the
	 *            itemid
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deleteitem(String id) {
		boolean flag = false;
		Item item = db.find(Item.class, id);
		if (PictureHandler.deletePic(item.getPicId())) {
			Response resp = db.remove(item);
			if (resp.getId().equals(id)) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * Update a item information to item_db
	 * 
	 * @param newItem the
	 *            new item which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updateitem(Item newItem) {
		boolean flag = false;
		Item item = db.find(Item.class, newItem.getItemId());
		item.setKeyword(newItem.getKeyword());
		item.setName(newItem.getName());
		item.setPrice(newItem.getPrice());
		item.setTime(newItem.getTime());
		item.setDiscount(newItem.getDiscount());
		Response resp = db.update(item);
		if (resp.getId().equals(item.getItemId())) {
			flag = true;
		}
		return flag;
	}

	/**
	 * find a item from item_db, the item picture name is "itemId.png"
	 * 
	 * @param id the itemid
	 * @param filePath the filePath to save item picture
	 * @return the entity of the item
	 * @author Tian
	 */
	public static Item findItemById(String id,String filePath) {
		Item item = db.find(Item.class, id);
		PictureHandler.getPic(item.getPicId(), filePath, item.getItemId());
		return item;
	}

	/**
	 * Find the items by SellerId
	 * @param SellerId is the id of the seller
	 * @return List<item> The items list which sellerId is match the para
	 */
	public static List<Item> findItemBySeller(String SellerId) {
		List<Item> items = new ArrayList<Item>();
		String find = "\"selector\": {  \"sellerId\": \""+SellerId+"\" }";
		items = db.findByIndex(find
				, Item.class);
			
		return items;
	}
	
	/**
	 * Find the items by the item name
	 * @param Name is the name of the item
	 * @return List<item> The items list which name is match the para
	 */
	public static List<Item> findItemByName(String Name) {
		List<Item> items = new ArrayList<Item>();
		String find = "\"selector\": {  \"name\": \""+Name+"\" }";
		items = db.findByIndex(find
				, Item.class);
			
		return items;
	}

}
