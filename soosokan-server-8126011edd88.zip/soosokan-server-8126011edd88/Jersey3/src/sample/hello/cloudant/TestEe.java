package Clondant.soosokan.handler;

import java.sql.Timestamp;

import Cloudant.soosokan.entity.Item;


public class TestEe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//warning: _id is key, when it already in db, test will be wrong, please change one before test!!!!!!!
//		Boolean result1 = AdsHandler.addAds(new Ads("091", "001", "We are soosokan", new Timestamp(123578876), 10000, 1));
//		System.out.println("save ads result: " + result1);
////		
		Boolean result2 = ItemHandler.addItem(new Item("ddddt", "001", "wo shi tian cai", "ghhgy is best", 0, new Timestamp(0), 10, "E://picture//12.png"));
		System.out.println("save item result: " + result2);
//		
//		Ads ads = AdsHandler.findAdsById("114");
//		System.out.println("Get ads from db result: "+ads.toString());
//		
//		Item item = ItemHandler.findItemById("114","d://" );
//		System.out.println("Get item from db result: "+item.toString());
		
		//warning: Please create Index before use(just one time)
		AdsHandler.CreateIndexBySellerId();
		PaymentHandler.CreateIndexBySellerId();
		ItemHandler.CreateIndexByName();
		ItemHandler.findItemBySeller("001");
	}

}
