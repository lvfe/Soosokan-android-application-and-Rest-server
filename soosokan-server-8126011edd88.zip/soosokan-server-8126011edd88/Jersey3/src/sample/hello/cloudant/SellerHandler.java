package Clondant.soosokan.handler;

import Cloudant.soosokan.entity.Seller;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.Response;

public class SellerHandler {

	private static CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");

	private static Database db = dbClient.database("seller_db", true);
	  
	/**
	 * Add a new seller to seller_db
	 * @param  the seller entity which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean addSeller(Seller seller){
		 boolean flag = false;
	     Response resp = db.save(seller);
	     if(resp.getId().equals(seller.getSellerId())){
	    	 flag = true;
	     }
	     return flag;
	}
	
	/**
	 * Remove a seller from seller_db
	 * @param the sellerid
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deleteSeller(String id){
		boolean flag = false;
		Seller seller = db.find(Seller.class, id);
		Response resp = db.remove(seller);
		if(resp.getId().equals(id)){
	    	 flag = true;
	     }
		return flag;
	}
	
	/**
	 * Update a seller information to seller_db
	 * @param the new seller which contains the information needs to update
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean updateSeller(Seller newSeller){
		boolean flag = false;
		Seller seller = db.find(Seller.class,newSeller.getSellerId());
		seller.setDescription(newSeller.getDescription());
		seller.setEmail(newSeller.getEmail());
		seller.setExpireDate(newSeller.getExpireDate());
		seller.setLatitude(newSeller.getLatitude());
		seller.setLongtitude(newSeller.getLongtitude());
		seller.setName(newSeller.getName());
		seller.setPassword(newSeller.getPassword());
		seller.setTelNumber(newSeller.getTelNumber());
		Response resp = db.update(seller);
		if(resp.getId().equals(seller.getSellerId())){
	    	 flag = true;
	     }
		return flag;
	}	
	
	/**
	 * find a seller from seller_db
	 * @param the sellerid
	 * @return the entity of the seller
	 * @author Tian
	 */
	public static Seller findSeller(String id){
		return db.find(Seller.class, id);
	}
	
}
