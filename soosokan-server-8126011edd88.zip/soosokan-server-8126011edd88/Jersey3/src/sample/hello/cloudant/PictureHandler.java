package sample.hello.cloudant;



import sample.hello.bean.Pic;

import com.cloudant.client.api.CloudantClient;
import com.cloudant.client.api.Database;
import com.cloudant.client.api.model.Attachment;
import com.cloudant.client.api.model.Params;
import com.cloudant.client.api.model.Response;

public class PictureHandler {
//	
	private static CloudantClient dbClient = new CloudantClient("soosokan", "soosokan", "soosokan1");
	private static Database db = dbClient.database("pic_db", true);

	/**
	 * Save the picture to the database
	 * @param filePath is the path of the picture
	 * @param itemID is the id of the item
	 * @return the document id in the cloudant db
	 * @author Tian
	 */
	public static String savePic(String filePath,String itemID){
		String Id = null;
		String db64 = Pic2Base64.GetImageStr(filePath);
		Attachment attachment = new Attachment(db64, "image/png");
		Pic pic = new Pic();
		pic.addAttachment(itemID +".png", attachment);
		Response response = db.save(pic);
		Id = response.getId();
		return Id;
	}
	/**
	 * Get the picture from the database and save it to the destination place
	 * @param filePath is the destination path to save the picture
	 * @param itemID is the id of the item
	 * @param id is the picture identify in the cloudant db
	 * @author Tian
	 */
	public static void getPic(String id,String filePath, String itemID){
		Pic pic2 = db.find(Pic.class, id, new Params().attachments());
		String base64Data = pic2.getAttachments().get(itemID+".png").getData();
		Pic2Base64.GenerateImage(base64Data,filePath+itemID+".png");
	}

	/**
	 * Remove a picture from pic_db
	 * @param the picId
	 * @return if it is success
	 * @author Tian
	 */
	public static boolean deletePic(String id){
		Boolean flag = false;
		Pic pic3 = db.find(Pic.class, id);
		Response resp = db.remove(pic3);
		if(resp.getId().equals(id)){
	    	 flag = true;
	     }
		return flag;
	}

}
