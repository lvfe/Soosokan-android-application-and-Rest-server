package sample.hello.bean;

import java.sql.Date;
import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Seller {
	
	private String name;
	private String _id;
	private String password;
	private float longtitude;
	private float latitude;
	private String email;
	private String telNumber;
	private Date expireDate;//Date time= new java.sql.Date(new java.util.Date().getTime());
	private String description;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSellerId() {
		return _id;
	}
	public void setSellerId(String sellerId) {
		this._id = sellerId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public float getLongtitude() {
		return longtitude;
	}
	public void setLongtitude(float longtitude) {
		this.longtitude = longtitude;
	}
	public float getLatitude() {
		return latitude;
	}
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelNumber() {
		return telNumber;
	}
	public void setTelNumber(String telNumber) {
		this.telNumber = telNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}
	
	public Seller(String name, String sellerId, String password,
			float longtitude, float latitude, String email, String telNumber,
			Date expireDate, String description) {
		super();
		this.name = name;
		this._id = sellerId;
		this.password = password;
		this.longtitude = longtitude;
		this.latitude = latitude;
		this.email = email;
		this.telNumber = telNumber;
		this.expireDate = expireDate;
		this.description = description;
	}
	public Seller() {
		// TODO Auto-generated constructor stub
	}
}
