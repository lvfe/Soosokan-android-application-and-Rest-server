package sample.hello.resources;

import java.sql.Timestamp;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import sample.hello.bean.Ads;
import sample.hello.cloudant.AdsHandler;

@Path("/hello")
public class HelloResource {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHello() {
		System.out.println("Hello test!");
		
//		Thread t = new Thread(){
//			public void run(){
				
		Boolean result1 = AdsHandler.addAds(new Ads("066", "001", "soosokan","We are soosokan", new Timestamp(123578876), 10000));
		System.out.println("save ads result: " + result1);
//		}
//		};
//		t.start();
		
		return "Hello Jersey";
	}
}
