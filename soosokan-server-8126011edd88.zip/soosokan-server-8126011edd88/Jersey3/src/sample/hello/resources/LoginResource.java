package sample.hello.resources;
import java.sql.*;
import java.text.ParseException;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.google.gson.JsonObject;

import sample.hello.bean.Seller;
import sample.hello.cloudant.SellerHandler;
import sample.hello.storage.LoginStore;
import sample.hello.util.DBConnector;

@Path("/login")
public class LoginResource {
	private final static String EMAIL = "email";
	private final static String PASSWORD = "password";
//	private LoginStore loginstore= new LoginStore();
	private SellerHandler sellerhandler = new SellerHandler();
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public Seller Login(MultivaluedMap<String, String> userParams) throws ClassNotFoundException, SQLException, ParseException{
			String email = userParams.getFirst(EMAIL);
			String password = userParams.getFirst(PASSWORD);
	
			System.out.println(email);
			System.out.println(password);
			
			Seller seller = SellerHandler.login(email, password);
//			Seller seller = loginstore.login(email,password);
			return seller;
		}
}

